<?php

namespace App\Http\Controllers;

use App\Http\Resources\AnuncioResource;
use App\Models\Anuncio;
use App\Models\Produto;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Http\Request;

class AnuncioController extends Controller
{
    use HasFactory;

    public function anunciar(object $request,string $id_p,string $id_u){
        $user = User::findOrFail($id_u);
        $produto = Produto::findOrFail($id_p);
        $data = $request->all();
        $anuncio = Anuncio::create($data);
        return new AnuncioResource($anuncio);
    }
}
